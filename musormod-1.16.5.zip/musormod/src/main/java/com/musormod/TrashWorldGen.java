package com.musormod;

import net.minecraft.block.Block;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.world.gen.blockplacer.SimpleBlockPlacer;
import net.minecraft.world.gen.blockstateprovider.SimpleBlockStateProvider;
import net.minecraft.world.gen.feature.BlockClusterFeatureConfig;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.placement.NoPlacementConfig;
import net.minecraft.world.gen.placement.Placement;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.WorldGenRegistries;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MusorMod.MODID)
public class TrashWorldGen {
    private static ConfiguredFeature<?, ?> TRASH_PATCH;

    public static void register() {
        Block block = ModBlocks.TRASH_PILE.get();
        TRASH_PATCH = Feature.RANDOM_PATCH
                .withConfiguration(new BlockClusterFeatureConfig.Builder(
                        new SimpleBlockStateProvider(block.getDefaultState()),
                        SimpleBlockPlacer.PLACER).tries(4).xSpread(5).zSpread(5).build())
                .withPlacement(Placement.HEIGHTMAP.configure(NoPlacementConfig.INSTANCE))
                .square()
                .chance(4);
        Registry.register(WorldGenRegistries.CONFIGURED_FEATURE,
                new ResourceLocation(MusorMod.MODID, "trash_patch"), TRASH_PATCH);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onBiomeLoad(BiomeLoadingEvent event) {
        Biome.Category c = event.getCategory();
        if (c == Biome.Category.NETHER || c == Biome.Category.THEEND
                || c == Biome.Category.OCEAN || c == Biome.Category.RIVER
                || c == Biome.Category.NONE) {
            return;
        }
        if (TRASH_PATCH != null) {
            event.getGeneration().withFeature(GenerationStage.Decoration.VEGETAL_DECORATION, TRASH_PATCH);
        }
    }
}
